This is an updated version of GenerateSimulations.py
in order to use it you need to download the wmpl python library and change GenerateSimulations.py in WesternMeteorPyLib\wmpl\MetSim\ML
